TPG Gas Station V1.1
====================

Install:
Copy the folder "TPG_Gas_Station_V1_1" into:
  Saved Games\DCS\Mods\tech\

Mission Editor:
Static Objects -> Structures -> TPG Gas Station V1.1

Contents:
- Four detailed fuel dispensers
- Convenience store and canopy
- Roadside price sign
- Rooftop HVAC and vent details
- Vehicle-friendly collision geometry
- Distance LODs
- Separate destroyed model
