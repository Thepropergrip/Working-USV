declare_plugin("TPG Gas Station V1.1",
{
    installed = true,
    dirName = current_mod_path,
    displayName = _("TPG Gas Station V1.1"),
    version = "1.1.0",
    state = "installed",
    info = _("Four-dispenser roadside gas station static structure")
})
mount_vfs_model_path(current_mod_path.."/Shapes")
mount_vfs_texture_path(current_mod_path.."/Textures")
dofile(current_mod_path.."/Database/db_tpg_gas_station.lua")
plugin_done()
