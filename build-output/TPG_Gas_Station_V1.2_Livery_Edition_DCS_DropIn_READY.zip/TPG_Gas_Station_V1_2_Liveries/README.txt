TPG Gas Station V1.2 - Livery Edition
======================================

Install:
Copy the single folder "TPG_Gas_Station_V1_2_Liveries" directly into:
  Saved Games\DCS\Mods\tech\

Mission Editor:
Static Objects -> Structures -> TPG Gas Station V1.2 Livery Edition

Liveries:
- USA: English signage; Regular 87 / Plus 89 / Premium 93; USD per gallon.
- Russia: Russian signage; AI-92 / AI-95 / AI-100; rubles per liter.
- Syria: Arabic signage; 90 / 95 / 98 grades; Syrian pounds per liter.

The physical station is identical between liveries. Only localized language,
pricing and units of measurement change. USA is the default/base appearance.

Retained from V1.1:
- Four detailed fuel dispensers
- Convenience store and canopy
- Illuminated/emissive roadside price display
- Rooftop HVAC and vent details
- Vehicle-friendly collision geometry
- Corrected raised asphalt forecourt (z-fighting fix)
- Distance LODs
- Separate destroyed model

This V1.2 uses a unique DCS namespace and can coexist with V1.1.
