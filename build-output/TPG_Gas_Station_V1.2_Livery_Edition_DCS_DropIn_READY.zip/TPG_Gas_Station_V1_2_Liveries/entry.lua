declare_plugin("TPG Gas Station V1.2 Livery Edition",
{
    installed = true,
    dirName = current_mod_path,
    displayName = _("TPG Gas Station V1.2 Livery Edition"),
    version = "1.2.0",
    state = "installed",
    info = _("Four-dispenser roadside gas station with USA, Russia and Syria liveries")
})
mount_vfs_model_path(current_mod_path.."/Shapes")
mount_vfs_texture_path(current_mod_path.."/Textures")
mount_vfs_liveries_path(current_mod_path.."/Liveries")
dofile(current_mod_path.."/Database/db_tpg_gas_station.lua")
plugin_done()
