import bpy
from grizzly_common import DESTROYED_LODS, INTACT_LODS, SUPPORT_COLLECTIONS, collection, ensure_dirs, reset_scene

ensure_dirs()
reset_scene()
for name in INTACT_LODS + DESTROYED_LODS + SUPPORT_COLLECTIONS:
    collection(name)
scene = bpy.context.scene
scene.render.engine = "BLENDER_EEVEE"
scene.render.resolution_x = 1400
scene.render.resolution_y = 1000
scene.render.resolution_percentage = 100
scene.render.image_settings.file_format = "PNG"
scene.world.color = (0.018, 0.022, 0.028)
scene.frame_start, scene.frame_end = 0, 200
scene.frame_set(100)
print("GRIZZLY_STAGE=01_scene_setup")
