import os
import bpy
import numpy as np
from grizzly_common import TEXTURES_DIR, create_image, edm_material

# Physically restrained coatings benchmarked against the DCS Massun92 container
# set: painted steel is nonmetallic and rough; only exposed hardware reads as
# metal.  The old nearly-black glossy frame created the toy/cartoon contrast.
palette = {
    "body": ((0.305,0.255,0.175,1), .78, .01, .75),
    "body_dark": ((0.185,0.150,0.095,1), .84, .01, .70),
    "steel": ((0.245,0.215,0.155,1), .73, .03, .85),
    "metal": ((0.105,0.112,0.108,1), .52, .82, .35),
    "rail": ((0.075,0.085,0.072,1), .68, .10, .55),
    "hardware": ((0.090,0.098,0.095,1), .48, .78, .35),
    "heatshield": ((0.070,0.074,0.068,1), .88, .30, .45),
    "connector": ((0.055,0.070,0.060,1), .63, .38, .40),
    "equipment": ((0.090,0.105,0.082,1), .72, .04, .60),
    "antenna": ((0.035,0.040,0.038,1), .58, .55, .30),
    "vent": ((0.025,0.028,0.026,1), .86, .08, .60),
    "actuator": ((0.145,0.150,0.140,1), .54, .72, .32),
    "label": ((0.155,0.145,0.118,1), .76, .02, .45),
    "warning": ((0.255,0.160,0.025,1), .70, .02, .50),
    "stencil": ((0.030,0.033,0.028,1), .82, .00, .35),
    "weld": ((0.215,0.185,0.130,1), .77, .06, .90),
    "burnt": ((0.030,0.027,0.023,1), .94, .12, .95),
}

def paint_map(name, color, seed, rough, metal, wear):
    rng=np.random.default_rng(seed)
    size=1024
    yy,xx=np.indices((size,size),dtype=np.float32)
    fine=rng.normal(0,1,(size,size)).astype(np.float32)
    # Smooth multi-frequency mill/paint structure.  Continuous waves avoid the
    # square value-noise patches that made the previous tan surface read as wood.
    surface=fine*.11
    for wavelength,amplitude in ((17,.12),(31,.15),(59,.18),(113,.22),(227,.22)):
        angle=float(rng.uniform(0,np.pi)); phase=float(rng.uniform(0,np.pi*2))
        projected=xx*np.cos(angle)+yy*np.sin(angle)
        surface+=np.sin(projected/wavelength+phase)*amplitude
    # Rain/grime streaks are low contrast and vertically biased, as on the
    # Massun92 PBR container, rather than uniform procedural speckle.
    streak_columns=(np.sin(xx/43.0+rng.uniform(0,6.28))*.38+
                    np.sin(xx/97.0+rng.uniform(0,6.28))*.34+
                    np.sin(xx/211.0+rng.uniform(0,6.28))*.28)
    streak=streak_columns*np.clip((yy/size)-.18,0,1)
    grime=np.clip((surface*.018+streak*.012)*wear,-.045,.045)
    base=np.ones((size,size,4),dtype=np.float32)
    base[:,:,:3]=np.clip(np.array(color[:3],dtype=np.float32)+grime[:,:,None],0,1)
    # Directional chips and handling scratches expose dark primer or steel.
    chips=(rng.random((size,size))>(1.0-.00045*wear))
    scratches=np.zeros((size,size),dtype=bool)
    for _ in range(int(18*wear)):
        sy=int(rng.integers(8,size-8)); sx=int(rng.integers(8,size-80)); length=int(rng.integers(18,95))
        scratches[sy:sy+int(rng.integers(1,3)),sx:sx+length]=True
    damage=chips|scratches
    primer=np.array((.055,.052,.045),dtype=np.float32) if metal<.30 else np.array((.10,.105,.10),dtype=np.float32)
    base[damage,:3]=primer
    rm=np.ones((size,size,4),dtype=np.float32)
    rm[:,:,0]=np.clip(.96-np.abs(streak)*.025*wear,.72,1.0)
    rm[:,:,1]=np.clip(rough+surface*.025+streak*.018*wear,0,1)
    rm[:,:,2]=metal
    rm[damage,1]=np.clip(rough-.18,.20,1.0); rm[damage,2]=np.maximum(metal,.68)
    # Tangent-space micro-normal derived from the same rolled/streaked height.
    height=surface*.30+streak*.16*wear
    gy,gx=np.gradient(height)
    strength=.42+.18*wear
    nx=-gx*strength; ny=-gy*strength; nz=np.ones_like(nx)
    norm=np.sqrt(nx*nx+ny*ny+nz*nz); nx/=norm; ny/=norm; nz/=norm
    normal=np.ones((size,size,4),dtype=np.float32)
    normal[:,:,0]=nx*.5+.5; normal[:,:,1]=ny*.5+.5; normal[:,:,2]=nz*.5+.5
    root="GRIZZLY_"+name
    return (
        create_image(root+"_Base",os.path.join(TEXTURES_DIR,root+"_Base.png"),base),
        create_image(root+"_Normal",os.path.join(TEXTURES_DIR,root+"_Normal.png"),normal),
        create_image(root+"_RoughMet",os.path.join(TEXTURES_DIR,root+"_RoughMet.png"),rm),
    )

images={role:paint_map(role,color,100+i,rough,metal,wear) for i,(role,(color,rough,metal,wear)) in enumerate(palette.items())}
materials={role:edm_material("GRIZZLY_"+role,color,rough,images[role][0],normal_image=images[role][1],roughmet_image=images[role][2],metallic=metal) for role,(color,rough,metal,wear) in palette.items()}
for obj in bpy.data.objects:
    role=obj.get("material_role")
    if role in materials and obj.type == "MESH":
        obj.data.materials.clear()
        obj.data.materials.append(materials[role])
print("GRIZZLY_STAGE=03_materials")
