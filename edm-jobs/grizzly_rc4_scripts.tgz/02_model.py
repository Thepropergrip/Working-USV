"""Original GRIZZLY 10-ft Tricon launcher geometry. No imported donor geometry."""
import math
from grizzly_common import *


# Release UV helper: directional 3x2 hard-surface atlas. Uses polygon normals
# so bevel faces do not flip projection axis vertex-by-vertex. Bounds cover the
# complete 10-ft module and keep texel density consistent between parts/LODs.
def grizzly_release_uv(obj):
    me=obj.data
    if not me.uv_layers: me.uv_layers.new(name="UVMap")
    uv=me.uv_layers.active.data
    xmin,xmax=-1.65,1.65; ymin,ymax=-1.32,1.32; zmin,zmax=-0.72,2.76
    margin=.018
    for poly in me.polygons:
        n=poly.normal; ax=max(range(3),key=lambda i:abs(n[i])); positive=n[ax]>=0
        tile={(0,True):0,(0,False):1,(1,True):2,(1,False):3,(2,True):4,(2,False):5}[(ax,positive)]
        col,row=tile%3,tile//3
        u0=col/3+margin/3; u1=(col+1)/3-margin/3; v0=row/2+margin/2; v1=(row+1)/2-margin/2
        for li in poly.loop_indices:
            co=obj.matrix_world @ me.vertices[me.loops[li].vertex_index].co
            if ax==0: s=(co.y-ymin)/(ymax-ymin); t=(zmax-co.z)/(zmax-zmin)
            elif ax==1: s=(co.x-xmin)/(xmax-xmin); t=(zmax-co.z)/(zmax-zmin)
            else: s=(co.x-xmin)/(xmax-xmin); t=(co.y-ymin)/(ymax-ymin)
            uv[li].uv=(u0+max(0,min(1,s))*(u1-u0), v0+max(0,min(1,t))*(v1-v0))

lod, lod1, lod2, lod3 = INTACT_LODS
dead, dead1, dead2 = DESTROYED_LODS
def b(name, loc, dims, role="body", bevel=.018, col=lod, rot=(0,0,0)):
    return add_box(name, loc, dims, col, role, rot, bevel, 3)
def c(name, loc, rad, depth, role="metal", rot=(0,0,0), col=lod, v=20):
    return add_cylinder(name, loc, rad, depth, col, role, rot, v)

def launcher_part(obj):
    obj["launcher_part"] = True
    return obj

def corrugated_panel(name, axis, fixed, lo, hi, z0, z1, outward, col=lod, role="body", ribs=12):
    """Pressed ISO sheet with a trapezoidal, not applique-bar, corrugation."""
    profile=[]
    pitch=(hi-lo)/float(ribs)
    for idx in range(ribs):
        start=lo+idx*pitch
        for fraction, depth in ((0.00,0.0),(0.17,.22),(0.30,1.0),(0.70,1.0),(0.83,.22)):
            profile.append((start+fraction*pitch,fixed+outward*depth))
    profile.append((hi,fixed))
    verts=[]
    for z in (z0,z1):
        for along, displaced in profile:
            verts.append((along,displaced,z) if axis=="Y" else (displaced,along,z))
    count=len(profile)
    faces=[]
    for idx in range(count-1): faces.append((idx,idx+1,count+idx+1,count+idx))
    mesh=bpy.data.meshes.new(name+"_Mesh")
    mesh.from_pydata(verts,[],faces); mesh.update()
    obj=bpy.data.objects.new(name,mesh); collection(col).objects.link(obj)
    solid=obj.modifiers.new("Pressed 2.5 mm steel","SOLIDIFY"); solid.thickness=.006
    bevel=obj.modifiers.new("Rolled press radii","BEVEL"); bevel.width=.006; bevel.segments=2; bevel.limit_method="ANGLE"
    bpy.context.view_layer.objects.active=obj; obj.select_set(True)
    bpy.ops.object.modifier_apply(modifier=solid.name); bpy.ops.object.modifier_apply(modifier=bevel.name)
    bpy.ops.object.mode_set(mode="EDIT"); bpy.ops.mesh.select_all(action="SELECT")
    grizzly_release_uv(obj)
    bpy.ops.object.mode_set(mode="OBJECT")
    obj.select_set(False)
    return mark(obj,role)

# 10-ft ISO/Tricon external envelope: 2.99 x 2.44 x 2.59 m.  The launcher
# remains original geometry, but now reads as a welded military cargo module:
# structural rails, ISO castings, corrugated steel and real cargo-door gear.
b("BottomRail", (0,0,.13), (3.08,2.53,.22), "steel", .025)
b("Floor", (0,0,.32), (2.91,2.34,.16), "body_dark", .010)

# Eight ISO corner castings plus continuous corner posts.
for x in (-1.44, 1.44):
    for y in (-1.16, 1.16):
        b("CornerPost_%s_%s"%(x,y), (x,y,1.43), (.17,.17,2.28), "steel", .018)
        for z, tag in ((.22,"LOW"),(2.56,"TOP")):
            b("ISO_Casting_%s_%s_%s"%(tag,x,y), (x,y,z), (.23,.23,.22), "steel", .028)
            # Recessed lifting sockets on both exposed faces read as cavities,
            # rather than the bright applique blocks used by the old model.
            b("ISO_Socket_%s_%s_%s"%(tag,x,y), (x+(.121 if x>0 else -.121),y,z), (.015,.094,.050), "body_dark", .006)
            b("ISO_SideSocket_%s_%s_%s"%(tag,x,y), (x,y+(.121 if y>0 else -.121),z), (.094,.015,.050), "body_dark", .006)
            if tag=="TOP": b("ISO_TopSocket_%s_%s"%(x,y),(x,y,z+.116),(.090,.050,.014),"body_dark",.004)

# Welded perimeter rails frame actual pressed corrugated sheet.  The previous
# separate rectangular "ribs" made the shell look like a stylized wooden crate.
for y in (-1.205,1.205):
    b("SideTopRail_"+str(y),(0,y,2.53),(2.78,.13,.15),"steel",.015)
    b("SideBottomRail_"+str(y),(0,y,.43),(2.78,.13,.15),"steel",.015)
    corrugated_panel("PressedSide_%s"%("P" if y>0 else "S"),"Y",y,-1.35,1.35,.50,2.46,.052 if y>0 else -.052,ribs=13)
    b("SideInner_"+str(y),(0,y+(-.040 if y>0 else .040),1.47),(2.70,.018,1.92),"body_dark",.003)
    for x in (-1.33,1.33): add_tube("SideWeld_%s_%s"%(y,x),(x,y+(.057 if y>0 else -.057),.50),(x,y+(.057 if y>0 else -.057),2.46),.008,lod,"weld",vertices=10)

# Rear corrugated end wall and its own welded boundary rails.
corrugated_panel("PressedRear","X",-1.49,-1.08,1.08,.50,2.46,-.052,ribs=10)
b("RearInner",(-1.45,0,1.47),(.018,2.16,1.92),"body_dark",.003)
for z in (.43,2.53): b("RearRail_"+str(z),(-1.48,0,z),(.14,2.24,.15),"steel",.014)
for y in (-1.08,1.08): add_tube("RearWeld_"+str(y),(-1.55,y,.50),(-1.55,y,2.46),.008,lod,"weld",vertices=10)

# Double cargo doors at +X: gasketed leaves, pressed vertical ribs, four
# full-height locking rods, cam keepers, hinge knuckles and restrained handles.
for y, suffix in ((-.595,"R"),(.595,"L")):
    b("DoorGasket_"+suffix,(1.541,y,1.47),(.018,1.105,2.075),"body_dark",.004)
    corrugated_panel("PressedDoor_"+suffix,"X",1.56,y-.505,y+.505,.50,2.46,.040,ribs=5)
    b("DoorInnerPanel_"+suffix,(1.525,y,1.47),(.018,1.015,1.91),"body_dark",.004)
    for rod_idx, dy in enumerate((-.27,.27)):
        ry=y+dy
        c("LockRod_%s_%d"%(suffix,rod_idx),(1.600,ry,1.47),.018,1.72,"metal",v=18)
        for z in (.61,2.32):
            c("LockCam_%s_%d_%s"%(suffix,rod_idx,z),(1.602,ry,z),.046,.035,"hardware",(0,math.pi/2,0),v=18)
            b("CamKeeper_%s_%d_%s"%(suffix,rod_idx,z),(1.620,ry,z),(.055,.12,.075),"steel",.008)
        # Folded locking handle and retainer near the lower third.
        add_tube("LockHandle_%s_%d"%(suffix,rod_idx),(1.625,ry,1.03),(1.625,ry+(.16 if dy<0 else -.16),.91),.016,lod,"metal",vertices=16)
        b("HandleRetainer_%s_%d"%(suffix,rod_idx),(1.626,ry+(.17 if dy<0 else -.17),.89),(.045,.09,.07),"hardware",.008)
    outer_y = -1.145 if y < 0 else 1.145
    for hinge_idx, z in enumerate((.58,1.17,1.76,2.35)):
        c("DoorHingePin_%s_%d"%(suffix,hinge_idx),(1.565,outer_y,z),.030,.17,"metal",v=18)
        b("DoorHingeLeaf_%s_%d"%(suffix,hinge_idx),(1.575,outer_y+(.07 if y<0 else -.07),z),(.055,.18,.065),"hardware",.007)

# Muted identification hardware and stencil blocks; no bright toy-like white.
b("CSC_DataPlate", (1.638,-.91,.71), (.012,.30,.18), "label", .003)
b("CSC_DataPlateInset",(1.646,-.91,.71),(.008,.25,.12),"stencil",.002)
b("HazardPlate", (1.638,.91,.71), (.012,.24,.16), "warning", .003)
for idx,(yy,zz,width) in enumerate(((-.72,1.00,.30),(-.72,.91,.22),(-.72,.82,.27),(.64,.73,.24),(.64,.64,.18))):
    b("DoorStencil_%02d"%idx,(1.648,yy,zz),(.006,width,.025),"stencil",.001)
b("DoorCenterSeal",(1.625,0,1.47),(.025,.045,2.07),"body_dark",.004)
for y in (-.79,.79): b("ApertureLongRim_"+str(y), (0,y,2.66),(2.14,.12,.14),"steel",.018)
for x in (-1.00,1.00): b("ApertureEndRim_"+str(x),(x,0,2.66),(.13,1.70,.14),"steel",.018)
# The old solid slab at z=2.50 visually occluded the magazine and made moving
# rails appear to pass through a lid.  The blast floor belongs below the cells;
# vertical liners protect the enclosure while leaving the aperture genuinely open.
b("BlastFloor", (0,0,1.10), (2.00,1.63,.09), "heatshield", .010)
for y in (-.77,.77): b("BlastLinerSide_"+str(y),(0,y,1.82),(1.92,.045,1.25),"heatshield",.006)
for x in (-.96,.96): b("BlastLinerEnd_"+str(x),(x,0,1.82),(.045,1.48,1.25),"heatshield",.006)
for row, x in enumerate((-.66,-.22,.22,.66)):
    for side, y in (("P",-.37),("S",.37)):
        key = "%s_%s"%(row,side)
        launcher_part(b("RailSpine_"+key,(x,y,1.84),(.10,.105,1.38),"rail",.012))
        launcher_part(b("RailGuide_"+key,(x,y-.105 if y<0 else y+.105,1.84),(.15,.035,1.17),"rail",.006))
        for z in (1.21,1.80,2.33): launcher_part(b("RetentionLug_%s_%s"%(key,z),(x,y,z),(.22,.17,.07),"metal",.009))
        launcher_part(c("Umbilical_"+key,(x,y,2.48),.035,.08,"connector",(math.pi/2,0,0),v=16))
        # Cable trough and local shock isolator make the M299-derived cells read
        # as equipment, rather than eight unsupported rectangular sticks.
        launcher_part(b("CableTrough_"+key,(x,y,1.47),(.16,.19,.055),"equipment",.008))
        launcher_part(c("RailIsolator_"+key,(x,y,1.22),.055,.055,"hardware",(math.pi/2,0,0),v=16))
for x in (-.90,-.44,0,.44,.90): launcher_part(b("MagazineCrossbeam_"+str(x),(x,0,1.28),(.055,1.46,.10),"steel",.008))
# Static trunnion bearings and stops show how the internal cradle carries the
# moving magazine.  The moving cross-shaft is parented with the launcher below.
for y in (-.82,.82):
    c("CradleBearing_"+str(y),(0,y,1.84),.13,.10,"hardware",(math.pi/2,0,0),v=28)
    b("CradlePedestal_"+str(y),(0,y,1.48),(.28,.20,.58),"steel",.018)
launcher_part(c("CradleCrossShaft",(0,0,1.84),.075,1.56,"metal",(math.pi/2,0,0),v=24))
print("GRIZZLY_STAGE=02a_container_magazine")

# Three asymmetric flip-out roof pieces: open at argument high-state, visibly hinged and braced.
def roof_panel(name, loc, dims, hinge_loc, argument, axis, high, col=lod, detailed=True):
    panel=b(name,loc,dims,"body",.018 if detailed else .008,col=col)
    b(name+"_HingeBeam",hinge_loc,(dims[0],.11,.12),"steel",.014 if detailed else .006,col=col)
    if detailed:
        underside=b(name+"_Underside",(loc[0],loc[1],loc[2]-.060),(dims[0]-.06,dims[1]-.06,.025),"body_dark",.004,col=col)
        parent_keep_world(underside,panel)
        for x in (-dims[0]*.40,0,dims[0]*.40): c(name+"_Hinge_"+str(x),(hinge_loc[0]+x,hinge_loc[1],hinge_loc[2]),.045,.14,"metal",(math.pi/2,0,0),col=col,v=16)
    pivot = bpy.data.objects.new(name+"_Pivot", None)
    pivot.location = hinge_loc
    collection(col).objects.link(pivot)
    parent_keep_world(panel,pivot)
    animate_rotation(pivot,argument,axis,0,high)
    return pivot
port=roof_panel("Roof_Port",(0,.90,2.69),(2.86,.82,.105),(0,.78,2.68),40,0,86)
stbd=roof_panel("Roof_Starboard",(0,-.90,2.69),(2.86,.82,.105),(0,-.78,2.68),40,0,-86)
aft=roof_panel("Roof_Aft",(-1.22,0,2.69),(.45,1.45,.105),(-1.01,0,2.68),40,1,76)
for name, pivot, start, end in (("Port",port,(-.9,.93,2.48),(-.9,.82,2.71)),("Stbd",stbd,(.9,-.93,2.48),(.9,-.82,2.71)),("Aft",aft,(-1.39,-.57,2.48),(-1.08,-.57,2.70))):
    rod=add_tube("RoofActuator_"+name,start,end,.027,lod,"actuator")
    parent_keep_world(rod,pivot)

# Sensor/C2 enclosure is intentionally modest: GRIZZLY is sensor/C2 agnostic, not a fictional radar truck.
b("C2Enclosure",(-1.16,0,2.57),(.36,.46,.20),"equipment",.020)
c("C2Antenna",(-1.16,0,2.87),.018,.46,"antenna",v=12)
for y in (-.15,.15): b("CoolingVent_"+str(y),(-1.34,y,2.58),(.012,.11,.09),"vent",.002)
# Sparse welded tie-down eyes; the old pegboard-like field of round fasteners
# was removed because ISO containers use welded corrugated sheet, not cabinet rivets.
for x in (-.98,.98):
    for y in (-.82,.82): c("TieDown_%s_%s"%(x,y),(x,y,.42),.055,.025,"metal",(math.pi/2,0,0),v=16)

# Populated distance models.  Each collection has an enclosure and launcher
# silhouette; none is intentionally empty.  The last LOD remains visible to
# 20 km so external-camera zoom never leaves eight floating missile models.
def distance_model(col, tag, detail):
    b(tag+"_Floor",(0,0,.25),(3.04,2.49,.28),"body_dark",.010 if detail>1 else .004,col=col)
    if detail>=2:
        for y in (-1.205,1.205):
            corrugated_panel(tag+"_Side_"+str(y),"Y",y,-1.35,1.35,.46,2.52,.045 if y>0 else -.045,col=col,ribs=8 if detail==3 else 5)
        corrugated_panel(tag+"_Rear","X",-1.49,-1.08,1.08,.46,2.52,-.045,col=col,ribs=6)
        corrugated_panel(tag+"_Doors","X",1.51,-1.08,1.08,.46,2.52,.035,col=col,ribs=8)
    else:
        for y in (-1.205,1.205): b(tag+"_Side_"+str(y),(0,y,1.49),(2.88,.06,2.08),"body",.004,col=col)
        b(tag+"_Rear",(-1.49,0,1.49),(.06,2.34,2.08),"body",.004,col=col)
        b(tag+"_Doors",(1.51,0,1.49),(.06,2.34,2.08),"body",.004,col=col)
    for x in (-1.44,1.44):
        for y in (-1.16,1.16): b(tag+"_Post_%s_%s"%(x,y),(x,y,1.43),(.18,.18,2.36),"steel",.010 if detail>1 else .004,col=col)
    for y in (-.79,.79): b(tag+"_ApertureLong_"+str(y),(0,y,2.66),(2.14,.13,.15),"steel",.006,col=col)
    for x in (-1.00,1.00): b(tag+"_ApertureEnd_"+str(x),(x,0,2.66),(.14,1.70,.15),"steel",.006,col=col)
    roof_panel(tag+"_RoofPort",(0,.90,2.69),(2.86,.82,.105),(0,.78,2.68),40,0,86,col=col,detailed=False)
    roof_panel(tag+"_RoofStbd",(0,-.90,2.69),(2.86,.82,.105),(0,-.78,2.68),40,0,-86,col=col,detailed=False)
    # A moving launcher mass remains visible even where individual guides are
    # no longer worth rendering.
    launcher_part(b(tag+"_Cradle",(0,0,1.84),(1.62,1.02,1.38),"rail",.010 if detail>1 else .004,col=col))
    if detail>=3:
        for idx,(x,y) in enumerate(((-.66,-.37),(-.66,.37),(-.22,-.37),(-.22,.37),(.22,-.37),(.22,.37),(.66,-.37),(.66,.37))):
            launcher_part(b(tag+"_Rail_%02d"%idx,(x,y,1.88),(.14,.14,1.46),"rail",.006,col=col))

distance_model(lod1,"LOD1",3)
distance_model(lod2,"LOD2",2)
distance_model(lod3,"LOD3",1)

# Separate low-profile destruction geometry: no intact container reused as a 'destroyed' stand-in.
b("DestroyedBase",(0,0,.24),(3.1,2.55,.30),"burnt",.035,dead,rot=(0,.04,.02))
b("DestroyedWall_Port",(-.10,1.0,1.20),(2.7,.18,1.7),"burnt",.025,dead,rot=(0,.18,.04))
b("DestroyedWall_Stbd",(.20,-1.0,1.03),(2.55,.20,1.45),"burnt",.025,dead,rot=(0,-.22,-.07))
b("DestroyedRoof",(-.18,0,1.95),(2.7,1.85,.13),"burnt",.025,dead,rot=(.30,-.08,.11))
for x,y in ((-.8,.35),(.25,-.42),(.92,.12)):
    add_tube("DestroyedRail_%s"%x,(x,y,.48),(x+.20,y+.10,2.15),.045,dead,"burnt")
# Coarse damaged silhouettes prevent the wreck from disappearing at distance.
for col,tag in ((dead1,"DestroyedLOD1"),(dead2,"DestroyedLOD2")):
    b(tag+"_Base",(0,0,.25),(3.10,2.55,.32),"burnt",.012,col=col,rot=(0,.04,.02))
    b(tag+"_WallA",(-.10,1.0,1.18),(2.70,.20,1.68),"burnt",.010,col=col,rot=(0,.18,.04))
    b(tag+"_WallB",(.20,-1.0,1.03),(2.55,.22,1.45),"burnt",.010,col=col,rot=(0,-.22,-.07))
print("GRIZZLY_STAGE=02b_roof_damage")
