import math
import os
import sys

import bpy
from mathutils import Vector


WORKSPACE = os.path.abspath(os.getcwd())
MOD_ROOT = os.path.join(WORKSPACE, "tmp", "grizzly-build", "TPG_GRIZZLY")
SOURCE_DIR = os.path.join(MOD_ROOT, "Source")
SCRIPT_DIR = os.path.join(SOURCE_DIR, "blender")
SHAPES_DIR = os.path.join(MOD_ROOT, "Shapes")
TEXTURES_DIR = os.path.join(MOD_ROOT, "Textures")
BLEND_PATH = os.path.join(SOURCE_DIR, "TPG_GRIZZLY_HELLFIRE.blend")
EDM_PATH = os.path.join(SHAPES_DIR, "TPG_GRIZZLY_HELLFIRE.edm")
DESTROYED_EDM_PATH = os.path.join(SHAPES_DIR, "TPG_GRIZZLY_HELLFIRE_destr.edm")
PREVIEW_PATH = os.path.join(SOURCE_DIR, "GRIZZLY_open_preview.png")
DESTROYED_PREVIEW_PATH = os.path.join(SOURCE_DIR, "GRIZZLY_destroyed_preview.png")

ADDON_DIR = os.path.join(WORKSPACE, "tmp", "blender-4.1.1", "blender-4.1.1-windows-x64", "4.1", "scripts", "addons", "io_scene_edm")

# The old build changed to empty collections after 80 m, which made the
# container and launcher disappear while DCS continued to draw the attached
# missile shapes.  These populated ranges deliberately retain a recognizable
# container silhouette at long external-camera distances.
INTACT_LODS = ("GRIZZLY_LOD_0_180", "GRIZZLY_LOD_1_900", "GRIZZLY_LOD_2_4500", "GRIZZLY_LOD_3_20000")
DESTROYED_LODS = ("GRIZZLY_DESTROYED_LOD_0_250", "GRIZZLY_DESTROYED_LOD_1_1500", "GRIZZLY_DESTROYED_LOD_2_8000")
SUPPORT_COLLECTIONS = ("COLLISION", "BOUNDING_BOX", "CONNECTORS")


def ensure_dirs():
    for path in (SOURCE_DIR, SCRIPT_DIR, SHAPES_DIR, TEXTURES_DIR):
        os.makedirs(path, exist_ok=True)


def enable_edm():
    if ADDON_DIR not in sys.path:
        sys.path.insert(0, ADDON_DIR)
    from utils import EDMPath
    EDMPath.full_plugin_path = ADDON_DIR
    bpy.ops.preferences.addon_enable(module="io_scene_edm")
    if not hasattr(bpy.ops.edm, "export"):
        raise RuntimeError("Official EDM exporter is unavailable")


def reset_scene():
    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.object.delete(use_global=False)
    for blocks in (bpy.data.meshes, bpy.data.curves, bpy.data.materials, bpy.data.cameras, bpy.data.lights):
        for item in list(blocks):
            blocks.remove(item)
    for item in list(bpy.data.collections):
        bpy.data.collections.remove(item)


def collection(name):
    result = bpy.data.collections.get(name)
    if result is None:
        result = bpy.data.collections.new(name)
        bpy.context.scene.collection.children.link(result)
    return result


def move_to_collection(obj, name):
    target = collection(name)
    for old in list(obj.users_collection):
        old.objects.unlink(obj)
    target.objects.link(obj)


def apply_transform(obj, location=False):
    bpy.ops.object.select_all(action="DESELECT")
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.transform_apply(location=location, rotation=True, scale=True)
    obj.select_set(False)


def mark(obj, role, damage=-1):
    obj["material_role"] = role
    if hasattr(obj, "EDMProps"):
        obj.EDMProps.DAMAGE_ARG = damage
    return obj


def add_box(name, loc, dims, col, role="hull", rotation=(0, 0, 0), bevel=0.0, segments=3, damage=-1):
    bpy.ops.mesh.primitive_cube_add(location=loc, rotation=rotation)
    obj = bpy.context.object
    obj.name = name
    obj.dimensions = dims
    apply_transform(obj)
    if bevel:
        mod = obj.modifiers.new("Manufactured edge radius", "BEVEL")
        mod.width = bevel
        mod.segments = segments
        mod.limit_method = "ANGLE"
        bpy.context.view_layer.objects.active = obj
        obj.select_set(True)
        bpy.ops.object.modifier_apply(modifier=mod.name)
        obj.select_set(False)
    move_to_collection(obj, col)
    return mark(obj, role, damage)


def add_cylinder(name, loc, radius, depth, col, role="metal", rotation=(0, 0, 0), vertices=32, damage=-1):
    bpy.ops.mesh.primitive_cylinder_add(vertices=vertices, radius=radius, depth=depth, location=loc, rotation=rotation)
    obj = bpy.context.object
    obj.name = name
    apply_transform(obj)
    for poly in obj.data.polygons:
        poly.use_smooth = True
    move_to_collection(obj, col)
    return mark(obj, role, damage)


def add_cone(name, loc, radius1, radius2, depth, col, role="metal", rotation=(0, 0, 0), vertices=32, damage=-1):
    bpy.ops.mesh.primitive_cone_add(vertices=vertices, radius1=radius1, radius2=radius2, depth=depth, location=loc, rotation=rotation)
    obj = bpy.context.object
    obj.name = name
    apply_transform(obj)
    for poly in obj.data.polygons:
        poly.use_smooth = True
    move_to_collection(obj, col)
    return mark(obj, role, damage)


def add_uv_sphere(name, loc, radius, col, role="metal", scale=(1, 1, 1), segments=32, rings=16):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=segments, ring_count=rings, radius=radius, location=loc)
    obj = bpy.context.object
    obj.name = name
    obj.scale = scale
    apply_transform(obj)
    for poly in obj.data.polygons:
        poly.use_smooth = True
    move_to_collection(obj, col)
    return mark(obj, role)


def add_profile_prism(name, profile, y0, y1, col, role="hull", bevel=0.0, damage=-1):
    verts = [(x, y0, z) for x, z in profile] + [(x, y1, z) for x, z in profile]
    n = len(profile)
    faces = [tuple(reversed(range(n))), tuple(range(n, 2 * n))]
    for i in range(n):
        j = (i + 1) % n
        faces.append((i, j, n + j, n + i))
    mesh = bpy.data.meshes.new(name + "_Mesh")
    mesh.from_pydata(verts, [], faces)
    mesh.update()
    obj = bpy.data.objects.new(name, mesh)
    collection(col).objects.link(obj)
    if bevel:
        mod = obj.modifiers.new("Welded edge radius", "BEVEL")
        mod.width = bevel
        mod.segments = 3
        mod.limit_method = "ANGLE"
        bpy.context.view_layer.objects.active = obj
        obj.select_set(True)
        bpy.ops.object.modifier_apply(modifier=mod.name)
        obj.select_set(False)
    return mark(obj, role, damage)


def add_ring_prism(name, outer, inner, y0, y1, col, role="track", damage=-1):
    """Extrude a closed 2D ring, used for a continuous track carcass."""
    if len(outer) != len(inner):
        raise ValueError("outer and inner track profiles must have equal vertex counts")
    count = len(outer)
    verts = []
    for y in (y0, y1):
        verts.extend((x, y, z) for x, z in outer)
        verts.extend((x, y, z) for x, z in inner)
    faces = []
    for side in range(2):
        base = side * count * 2
        for i in range(count):
            j = (i + 1) % count
            if side == 0:
                faces.append((base + i, base + j, base + count + j, base + count + i))
            else:
                faces.append((base + i, base + count + i, base + count + j, base + j))
    far = count * 2
    for i in range(count):
        j = (i + 1) % count
        faces.append((i, far + i, far + j, j))
        faces.append((count + i, count + j, far + count + j, far + count + i))
    mesh = bpy.data.meshes.new(name + "_Mesh")
    mesh.from_pydata(verts, [], faces)
    mesh.update()
    obj = bpy.data.objects.new(name, mesh)
    collection(col).objects.link(obj)
    bevel = obj.modifiers.new("Molded track edge", "BEVEL")
    bevel.width = 0.006
    bevel.segments = 2
    bevel.limit_method = "ANGLE"
    bpy.context.view_layer.objects.active = obj
    obj.select_set(True)
    bpy.ops.object.modifier_apply(modifier=bevel.name)
    obj.select_set(False)
    return mark(obj, role, damage)


def add_torus(name, loc, major_radius, minor_radius, col, role="hardware", rotation=(0, 0, 0), major_segments=40, minor_segments=12, damage=-1):
    bpy.ops.mesh.primitive_torus_add(
        major_radius=major_radius,
        minor_radius=minor_radius,
        major_segments=major_segments,
        minor_segments=minor_segments,
        location=loc,
        rotation=rotation,
    )
    obj = bpy.context.object
    obj.name = name
    apply_transform(obj)
    for poly in obj.data.polygons:
        poly.use_smooth = True
    move_to_collection(obj, col)
    return mark(obj, role, damage)


def add_tube(name, start, end, radius, col, role="metal", vertices=24):
    a, b = Vector(start), Vector(end)
    direction = b - a
    obj = add_cylinder(name, (a + b) * 0.5, radius, direction.length, col, role, vertices=vertices)
    obj.rotation_euler = direction.to_track_quat("Z", "Y").to_euler()
    apply_transform(obj)
    return obj


def add_curve_tube(name, points, radius, col, role="cable", bevel_resolution=3):
    curve = bpy.data.curves.new(name + "_Curve", "CURVE")
    curve.dimensions = "3D"
    curve.resolution_u = 3
    curve.bevel_depth = radius
    curve.bevel_resolution = bevel_resolution
    spline = curve.splines.new("NURBS")
    spline.points.add(len(points) - 1)
    for index, point in enumerate(points):
        spline.points[index].co = (*point, 1.0)
    spline.order_u = min(3, len(points))
    spline.use_endpoint_u = True
    obj = bpy.data.objects.new(name, curve)
    collection(col).objects.link(obj)
    bpy.ops.object.select_all(action="DESELECT")
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.convert(target="MESH")
    obj = bpy.context.object
    obj.name = name
    return mark(obj, role)


def add_connector(name, loc, rotation=(0, 0, 0), col="CONNECTORS"):
    obj = bpy.data.objects.new(name, None)
    obj.empty_display_type = "ARROWS"
    obj.empty_display_size = 0.12
    obj.location = loc
    obj.rotation_euler = rotation
    obj.EDMProps.SPECIAL_TYPE = "CONNECTOR"
    collection(col).objects.link(obj)
    return obj


def parent_keep_world(obj, parent):
    bpy.context.view_layer.update()
    world = obj.matrix_world.copy()
    obj.parent = parent
    obj.matrix_parent_inverse = parent.matrix_world.inverted()
    obj.matrix_world = world
    bpy.context.view_layer.update()


def animate_rotation(obj, argument, axis, low_deg, high_deg):
    animate_rotation_keys(obj, argument, axis, ((0, low_deg), (100, 0.0), (200, high_deg)))


def animate_rotation_keys(obj, argument, axis, frame_degrees):
    """Key a DCS draw argument and restore the scene's evaluated pose.

    Blender leaves the property at the value from the last inserted key even
    when the timeline is on another frame. Restoring evaluation here is
    important before child pivots/connectors are parented to an animated node.
    """
    current_frame = bpy.context.scene.frame_current
    action = bpy.data.actions.new(f"{argument}_{obj.name}")
    obj.animation_data_create()
    obj.animation_data.action = action
    base = list(obj.rotation_euler)
    for frame, angle in frame_degrees:
        rot = base[:]
        rot[axis] = math.radians(angle)
        obj.rotation_euler = rot
        obj.keyframe_insert("rotation_euler", frame=frame, group="DCS Argument")
    for curve in action.fcurves:
        for key in curve.keyframe_points:
            key.interpolation = "LINEAR"
    bpy.context.scene.frame_set(current_frame)
    bpy.context.view_layer.update()


def animate_recoil(obj, argument, distance):
    action = bpy.data.actions.new(f"{argument}_{obj.name}")
    obj.animation_data_create()
    obj.animation_data.action = action
    base = obj.location.copy()
    for frame, offset in ((0, 0.0), (100, -distance)):
        obj.location = base + Vector((offset, 0, 0))
        obj.keyframe_insert("location", frame=frame, group="DCS Argument")
    for curve in action.fcurves:
        for key in curve.keyframe_points:
            key.interpolation = "LINEAR"


def animate_wheel(obj, argument):
    action = bpy.data.actions.new(f"{argument}_{obj.name}")
    obj.animation_data_create()
    obj.animation_data.action = action
    base = obj.rotation_euler.copy()
    for frame, turn in ((0, -180.0), (100, 0.0), (200, 180.0)):
        # Wheel meshes are transform-applied with their axle on model Y.
        obj.rotation_euler = (base.x, base.y + math.radians(turn), base.z)
        obj.keyframe_insert("rotation_euler", frame=frame, group="DCS Argument")
    for curve in action.fcurves:
        for key in curve.keyframe_points:
            key.interpolation = "LINEAR"


def animate_track_phase(obj, argument, distance):
    action = bpy.data.actions.new(f"{argument}_{obj.name}")
    obj.animation_data_create()
    obj.animation_data.action = action
    base = obj.location.copy()
    for frame, phase in ((0, -distance), (100, 0.0), (200, distance)):
        obj.location = base + Vector((phase, 0, 0))
        obj.keyframe_insert("location", frame=frame, group="DCS Argument")
    for curve in action.fcurves:
        for key in curve.keyframe_points:
            key.interpolation = "LINEAR"


def create_image(name, path, pixels):
    import numpy as np
    array = np.asarray(pixels, dtype=np.float32)
    h, w, _ = array.shape
    image = bpy.data.images.new(name, width=w, height=h, alpha=True)
    image.pixels.foreach_set(array.reshape(-1))
    image.filepath_raw = path
    image.file_format = "PNG"
    image.save()
    image.name = name
    return image


def edm_material(name, color, roughness, base_image=None, normal_image=None, roughmet_image=None, metallic=0.0, emissive=0.0):
    from materials.materials import build_material_descriptions
    desc = build_material_descriptions()["EDM_Default_Material"]
    material = bpy.data.materials.new(name)
    material.use_nodes = True
    material.node_tree.nodes.clear()
    output = material.node_tree.nodes.new("ShaderNodeOutputMaterial")
    shader = material.node_tree.nodes.new("EdmDefaultShaderNodeType")
    shader.post_init(desc)
    shader.transparency = "OPAQUE"
    shader.shadow_caster = "SHADOW_CASTER_YES"
    if "Transparency" in shader.inputs:
        shader.inputs["Transparency"].default_value = "OPAQUE"
    if "Shadow Caster" in shader.inputs:
        shader.inputs["Shadow Caster"].default_value = "SHADOW_CASTER_YES"
    material.node_tree.links.new(shader.outputs[0], output.inputs["Surface"])
    shader.inputs["Base Color"].default_value = color
    shader.inputs["RoughMet (Non-Color)"].default_value = (1.0, roughness, metallic, 1.0)
    shader.inputs["Emissive"].default_value = color
    shader.inputs["Emissive Value"].default_value = emissive
    for image, socket, noncolor in ((base_image, "Base Color", False), (normal_image, "Normal (Non-Color)", True), (roughmet_image, "RoughMet (Non-Color)", True)):
        if image is not None and socket in shader.inputs:
            node = material.node_tree.nodes.new("ShaderNodeTexImage")
            node.image = image
            if noncolor:
                image.colorspace_settings.name = "Non-Color"
            material.node_tree.links.new(node.outputs["Color"], shader.inputs[socket])
    return material


def glass_material(name, color, filter_image, roughmet_image):
    from materials.materials import build_material_descriptions
    desc = build_material_descriptions()["EDM_Glass_Material"]
    material = bpy.data.materials.new(name)
    material.use_nodes = True
    material.node_tree.nodes.clear()
    output = material.node_tree.nodes.new("ShaderNodeOutputMaterial")
    shader = material.node_tree.nodes.new("EdmGlassShaderNodeType")
    shader.post_init(desc)
    shader.transparency = "ALPHA_BLENDING"
    shader.shadow_caster = "SHADOW_CASTER_NO"
    shader.glass_type = "GLASS_INSTRUMENTAL"
    if "Transparency" in shader.inputs:
        shader.inputs["Transparency"].default_value = "ALPHA_BLENDING"
    if "Shadow Caster" in shader.inputs:
        shader.inputs["Shadow Caster"].default_value = "SHADOW_CASTER_NO"
    if "Glass Type" in shader.inputs:
        shader.inputs["Glass Type"].default_value = "GLASS_INSTRUMENTAL"
    material.node_tree.links.new(shader.outputs[0], output.inputs["Surface"])
    values = {"Glass Color (Color Filter)": color, "Glass Alpha*": 0.38, "Diffuse Color (Dirt)": (0.02, 0.025, 0.018, 1), "Diffuse Alpha*": 0.08, "RoughMet (Non-Color)": (1, 0.05, 0.03, 1), "Opacity Value": 0.55}
    for socket, value in values.items():
        if socket in shader.inputs:
            shader.inputs[socket].default_value = value
    for image, socket, noncolor in ((filter_image, "Glass Color (Color Filter)", False), (roughmet_image, "RoughMet (Non-Color)", True)):
        if socket in shader.inputs:
            node = material.node_tree.nodes.new("ShaderNodeTexImage")
            node.image = image
            if noncolor:
                image.colorspace_settings.name = "Non-Color"
            material.node_tree.links.new(node.outputs["Color"], shader.inputs[socket])
    return material


def set_collection_visible(name, visible):
    col = bpy.data.collections.get(name)
    if col:
        col.hide_render = not visible
        col.hide_viewport = not visible


def triangle_count(names):
    return sum(max(0, len(poly.vertices) - 2) for name in names for obj in collection(name).objects if obj.type == "MESH" for poly in obj.data.polygons)
