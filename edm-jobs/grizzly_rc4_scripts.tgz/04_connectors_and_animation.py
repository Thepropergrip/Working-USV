import bpy
import math
from grizzly_common import add_connector, animate_rotation, collection, parent_keep_world

# RC4 target-relative VLS indexing.
#
# The missile axis remains exactly vertical (+Z).  A co-located invisible pivot
# rotates only the connector frame around global Z on DCS draw argument 0.  This
# gives DCS/type-8 artillery an unambiguous target-relative dog-leg plane without
# translating the missile cell, swinging the rack, or forcing the round to make
# a 180-degree correction after launch.
#
# The cell center is lowered 0.40 m from the old 3.24 m to 2.84 m so roughly
# 40% of the 1.63 m Hellfire/JAGM body is nested below the ~2.66 m roof aperture
# in the full-red-alert state.
MISSILE_SOCKET_Z = 2.84
CELL_POSITIONS = ((-.66,-.37),(-.66,.37),(-.22,-.37),(-.22,.37),(.22,-.37),(.22,.37),(.66,-.37),(.66,.37))

for index, (x, y) in enumerate(CELL_POSITIONS, 1):
    pivot = bpy.data.objects.new("GRIZZLY_VLS_YAW_%02d" % index, None)
    pivot.empty_display_type = "PLAIN_AXES"
    pivot.empty_display_size = 0.09
    pivot.location = (x, y, MISSILE_SOCKET_Z)
    collection("CONNECTORS").objects.link(pivot)

    connector = add_connector(
        "POINT_GRIZZLY_%02d" % index,
        (x, y, MISSILE_SOCKET_Z),
        rotation=(0, -math.pi / 2, 0),
    )
    parent_keep_world(connector, pivot)

    # Argument 0 maps the native WS azimuth onto the connector's vertical-axis
    # roll/yaw.  Frames 0/100/200 are -180/0/+180 degrees.
    animate_rotation(pivot, 0, 2, -180, 180)

add_connector("CENTER_GRIZZLY", (0, 0, 2.10))
add_connector("POINT_GRIZZLY_SMOKE", (0, 0, 3.12))
print("GRIZZLY_STAGE=04_connectors_RC4_TARGET_RELATIVE_VLS_Z2.84")
